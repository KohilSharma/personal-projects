
var table = document.querySelector('#pixelCanvas');

function makeGrid(evt) {
	evt.preventDefault();
	table.innerHTML = '';		// clear the grid

	var inputHeight = document.querySelector('#inputHeight');
	var inputWidth = document.querySelector('#inputWidth');

	for (let i = 0; i < inputHeight.value; i++) {		// create a customized grid
		for (let j = 0; j < inputWidth.value; j++) {
			table.appendChild(document.createElement('td'));
		}
		table.appendChild(document.createElement('tr'));
	}
}


function colorCell(evt) {

	var colorInput = document.querySelector('#colorPicker').value;

	if (evt.target.nodeName === 'TD') {
		evt.target.style.backgroundColor = colorInput;		// change a particular cell's color
	}
}

document.querySelector('#sizePicker').addEventListener('submit', makeGrid, true);

table.addEventListener('click', colorCell);